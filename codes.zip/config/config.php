<?php
/**
 * Bookexa — Configuration File
 *
 * Local XAMPP URL: http://localhost/bookexa/
 * Live cPanel URL: https://bookexa.com/
 *
 * Leave 'base_url' and 'base_path' empty ('') for automatic detection on both
 * XAMPP subfolders (/bookexa) and cPanel domain roots (/).
 */

return [
    'app_name'  => 'Bookexa',
    'app_env'   => 'local', // Set to 'production' on live cPanel server
    'timezone'  => 'Asia/Dhaka',

    // Auto-detected when empty (''). Override if needed (e.g. 'https://bookexa.com')
    'base_url'  => '',
    'base_path' => '',

    // MySQL / MariaDB credentials (change user/pass on live cPanel!)
    'db' => [
        'host'    => '127.0.0.1', // Usually 'localhost' on cPanel
        'port'    => '3306',
        'name'    => 'bookexa',
        'user'    => 'root',
        'pass'    => '',
        'charset' => 'utf8mb4',
    ],

    // Security settings (replace app_secret on live server!)
    'security' => [
        'app_secret'        => 'bx_7e2a9c4f1b8d3e6a0c5f2b9d4e8a1c6f3b5d7a9e2c4b6f0a',
        'pdf_cache_enabled' => true,
        'pdf_cache_ttl'     => 21600, // 6 hours protected server-side cache
    ],

    // Optional CDN Image Storage & Sync (works completely without CDN when enabled => false)
    'cdn' => [
        'enabled'    => false,
        'driver'     => 'filesystem', // 'filesystem' | 'ftp' | 'http'
        'base_url'   => '',           // e.g. 'https://cdn.domain.com/bookexa' or XAMPP 'http://localhost/bookexa-cdn/bookexa'
        'path'       => '',           // filesystem driver: '/home/USER/cdn.domain.com' or XAMPP 'C:/xampp/htdocs/bookexa-cdn'
        'ftp'        => [
            'host' => '',
            'port' => 21,
            'user' => '',
            'pass' => '',
            'root' => '/',
            'ssl'  => true,
        ],
        'http'       => [
            'endpoint' => '',
            'secret'   => '',
        ],
        'sync_batch' => 10,
    ],
];
